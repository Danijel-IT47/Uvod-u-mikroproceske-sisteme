#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float x1, y1, z1;
    float x2, y2, z2;
    float rastojanje;
    printf("Unesite kordinate prve tacke(x, y, z): ");
    scanf("%f, %f, %f", &x1, &y1, &z1);
    printf("Unesite kordinate druge tacke(x, y, z): ");
    scanf("%f, %f, %f", &x2, &y2, &z2);
    rastojanje = sqrt(pow(x2 - x1, 2)+ pow(y2 - y1, 2) + pow(z2 - z1, 2));
    printf("Rastojanje izmedju tacaka je %.2f", rastojanje);
    return 0;
}
