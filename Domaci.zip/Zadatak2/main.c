#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float a, b, c;
    printf("Unesi duzinu stranice a: ");
    scanf("%f", &a);
    printf("Unesi duzinu stranice b: ");
    scanf("%f", &b);
    c = sqrt(a * a + b * b);
    printf("c = %.2f", c);
    return 0;
}
